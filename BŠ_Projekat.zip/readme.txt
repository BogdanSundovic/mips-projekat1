Bogdan Šundovic 641/2021

Veći broj samoglasnika(9) od suglasnika(5) pa uzimam port A.
14 % 6 = 2 (broj pina)
Širina impulsa je: 6
Širina pauze je: 8
Broj ponavljanja je 6 i 8
